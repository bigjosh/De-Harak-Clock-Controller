#!/bin/sh
# Deploy one clock digit using its DNS name and production FFS index.
set -eu

usage() {
    printf '%s\n' 'usage: deploy-trial-digit.sh DIGIT [--bundle FILE] [--known-hosts FILE] [--no-startup-flash] [--no-idle-flash]' \
        '  DIGIT is H01-H12 or M00-M59 (case-insensitive).' \
        '  Imports the target LEDscape settings and sets FFS: H01=0, H12=11, M00=12, M59=71.'
}

fail() { printf 'deploy-trial-digit: %s\n' "$1" >&2; exit 2; }

if [ "$#" -eq 1 ] && [ "$1" = --help ]; then usage; exit 0; fi
[ "$#" -ge 1 ] || { usage >&2; exit 2; }
digit=$1
shift
case "$digit" in
    [hH]0[1-9]|[hH]1[0-2]) prefix=h; offset=-1 ;;
    [mM][0-5][0-9]) prefix=m; offset=12 ;;
    *) fail 'use a digit name H01-H12 or M00-M59, including both digits' ;;
esac
digits=${digit#?}
tens=${digits%?}
ones=${digits#?}
# Parse the two digits separately: POSIX shells may treat 08/09 as octal.
index=$((tens * 10 + ones + offset))
target=$prefix$digits

# Validate without changing the argv later passed to the existing launcher.
# The digit name owns the index; a local panel file could override that mapping.
validate_options() {
    while [ "$#" -gt 0 ]; do
        case "$1" in
            --bundle|--known-hosts)
                [ "$#" -ge 2 ] || fail "missing value for $1"
                case "$2" in ''|--*) fail "missing value for $1" ;; esac
                shift 2 ;;
            --no-startup-flash|--no-idle-flash) shift ;;
            --ffs-index) fail 'the FFS index is derived from the digit name and cannot be overridden' ;;
            *) usage >&2; fail "unsupported argument: $1" ;;
        esac
    done
}
validate_options "$@"

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
printf 'Digit %s -> FFS index %s\n' "$target" "$index"
exec sh "$script_dir/deploy-trial.sh" "$target" --ffs-index "$index" "$@"
